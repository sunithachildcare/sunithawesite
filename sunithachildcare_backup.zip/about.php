<?php include('header.php'); ?> 
  <!--==============================content================================-->
    <section id="content"><div class="ic">More Website Templates @ TemplateMonster.com. April 23, 2012!</div>
        <div class="container_12">	
          <div class="grid_4 bot-1">
            <div class="art"></div>
            <h2 class="top-1 p2">Events</h2>
            <p class="text-1 p3">January -20 - “Spring’s Bloom”</p>
            <p>The PSD source files of this <a href="http://blog.templatemonster.com/2012/04/23/free-website-template-justslider-art-school/" class="link">Art School Template</a> are available for free for the registered members of TemplateMonster.com. Feel free to <br>get them!</p>
            <p class="text-1 top-2 p3">April 01 - “Smile!”</p>
            <p>This website template has several pages: Home Page, About Us, Schedule, Gallery, Contact Us (note that contact us form – <br>doesn’t work).</p>
            <a href="#" class="link-1 top-3">News Archive</a>
          </div>
          <div class="grid_8">
            <div class="block-1">
            	<div class="block-1-shadow">
                	<h2 class="clr-6 p4">Our Gallery</h2>
                    <div class="box-1">
                    	<a href="#" class="img-border"><img src="images/img1.jpg" alt=""></a>
                    	<p class="text-2">Jennifer, 10 years</p>
                    </div>
                    <div class="box-1 last">
                    	<a href="#" class="img-border"><img src="images/img2.jpg" alt=""></a>
                    	<p class="text-2">Martin, 13 years</p>
                    </div>
                    <div class="clear p5"></div>
                    <div class="box-1">
                    	<a href="#" class="img-border"><img src="images/img3.jpg" alt=""></a>
                    	<p class="text-2">Sebastian, 14 years</p>
                    </div>
                    <div class="box-1 last">
                    	<a href="#" class="img-border"><img src="images/img4.jpg" alt=""></a>
                    	<p class="text-2">Fiona, 8 years</p>
                    </div>
                    <div class="clear"></div>
                    <div class="pad-2">
                    	<a href="#" class="link-2">Full Gallery</a>
                    </div>
                </div>
            </div>
          </div>
          <div class="clear"></div>
        </div>
    </section>
<?php include('footer.php'); ?>