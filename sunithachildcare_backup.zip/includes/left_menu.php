<style type="text/css">
#left{float:left;width:200px;height:100%}
#left ul li{ background-color: #ccc;border: 1px solid #aaa;border-radius: 6px;margin: 2px;font-weight: bold;padding:3px; }
#left ul li a:hover{color : #17B5FE;}
</style>
<div id="left">
	<ul>
		<li><a href="galleryUp.php">Upload gallery</a></li>
		<li><a href="editGallery.php">Edit/delete gallery</a></li>
		<li><a href="events.php">Upload Events</a></li>
	</ul>
</div>